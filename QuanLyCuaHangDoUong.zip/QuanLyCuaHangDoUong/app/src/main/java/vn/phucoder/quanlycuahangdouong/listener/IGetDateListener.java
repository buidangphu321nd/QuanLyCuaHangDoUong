package vn.phucoder.quanlycuahangdouong.listener;

public interface IGetDateListener {
    void getDate(String date);
}
