package vn.phucoder.quanlycuahangdouong.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import vn.phucoder.quanlycuahangdouong.R;

public class RevelueActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_revelue);
    }
}